# RIP-to-REST – Protocol Conversion with REST APIs

## Setup Instructions

1. **Install Dependencies**
   ```bash
   pip install flask flask-restx netmiko